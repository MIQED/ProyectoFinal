bootstrap-calendar
==================

Implementación de bootstrap calendar con php/codeigniter

* [Visita el video tutorial](http://uno-de-piera.com/bootstrap-calendar-calendario-con-eventos-con-php-y-mysql)
